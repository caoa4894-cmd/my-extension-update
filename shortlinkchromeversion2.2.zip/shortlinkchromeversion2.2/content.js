// content.js - 简化版本，确保在页面中运行
console.log('MiniUrl 内容脚本已加载');

// 检查是否是白名单网站
function checkIfWhitelisted() {
    // 获取当前域名
    const hostname = window.location.hostname.toLowerCase().replace('www.', '');
    console.log('当前域名:', hostname);
    
    // 检查是否是禁止的域名
    if (hostname.includes('temu.com')) {
        console.log('TEMU平台，禁止自动弹出');
        return; // 直接返回，不发送自动弹出消息
    }
    
    // 从存储中获取白名单
    chrome.storage.local.get(['whitelistData'], function(result) {
        if (chrome.runtime.lastError) {
            console.error('获取存储错误:', chrome.runtime.lastError);
            return;
        }
        
        console.log('存储数据:', result);
        
        const whitelistData = result.whitelistData;
        
        if (!whitelistData || !whitelistData.sites) {
            console.log('没有找到白名单数据');
            return;
        }
        
        // 检查是否在白名单中
        const isWhitelisted = whitelistData.sites.some(site => {
            const domain = site.domain.toLowerCase();
            console.log('检查域名:', domain, 'vs', hostname);
            return hostname === domain || hostname.endsWith('.' + domain);
        });
        
        console.log('是否在白名单中:', isWhitelisted);
        
        if (isWhitelisted && whitelistData.autoPopup !== false) {
            console.log('发送自动弹出消息');
            
            // 发送消息到后台
            chrome.runtime.sendMessage({
                action: 'autoPopup',
                url: window.location.href,
                title: document.title,
                hostname: hostname
            }, function(response) {
                console.log('消息发送响应:', response);
            });
        }
    });
}
// 页面加载完成后执行
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM加载完成，开始检查白名单');
        setTimeout(checkIfWhitelisted, 1000); // 延迟1秒确保存储加载
    });
} else {
    console.log('DOM已加载，直接检查白名单');
    setTimeout(checkIfWhitelisted, 1000);
}

// 监听URL变化（对于SPA应用）
let lastUrl = location.href;
new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        console.log('URL变化:', currentUrl);
        setTimeout(checkIfWhitelisted, 500);
    }
}).observe(document, { subtree: true, childList: true });