// background-service.js - 修复版本
console.log('MiniUrl 后台服务已启动');

// 处理来自内容脚本的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('收到消息:', message);
    
    if (message.action === 'autoPopup') {
        console.log('处理自动弹出请求');
        console.log('URL:', message.url);
        console.log('标题:', message.title);
        
        // 检查是否是temu.com
        if (message.url.includes('temu.com')) {
            console.log('TEMU平台，禁止弹出');
            sendResponse({ success: false, reason: 'temu_blocked' });
            return true;
        }
        
        // 尝试直接打开popup
        try {
            chrome.action.openPopup().then(() => {
                console.log('成功打开popup');
            }).catch(error => {
                console.log('无法直接打开popup，创建通知:', error);
                createNotification(message);
            });
        } catch (error) {
            console.log('打开popup失败，创建通知:', error);
            createNotification(message);
        }
        
        sendResponse({ success: true });
    }
    
    return true; // 保持消息通道开放
});

// 创建通知函数
function createNotification(message) {
    console.log('创建通知');
    
    const notificationOptions = {
        type: 'basic',
        iconUrl: 'icon.png',
        title: 'MiniUrl 检测到跨境平台',
        message: `${message.title || '检测到跨境平台'} - 点击生成短链接`,
        priority: 2,
        requireInteraction: true,
        buttons: [
            { title: '生成短链接' }
        ]
    };
    
    chrome.notifications.create('miniurl-auto-popup', notificationOptions, (notificationId) => {
        if (chrome.runtime.lastError) {
            console.error('创建通知失败:', chrome.runtime.lastError);
        } else {
            console.log('通知创建成功，ID:', notificationId);
        }
    });
}

// 点击通知的处理
chrome.notifications.onClicked.addListener((notificationId) => {
    console.log('通知被点击:', notificationId);
    chrome.action.openPopup().catch(error => {
        console.error('打开popup失败:', error);
    });
});

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    console.log('通知按钮被点击:', notificationId, buttonIndex);
    if (buttonIndex === 0) {
        chrome.action.openPopup().catch(error => {
            console.error('打开popup失败:', error);
        });
    }
});

// 扩展安装时初始化默认数据
chrome.runtime.onInstalled.addListener((details) => {
    console.log('扩展安装/更新:', details.reason);
    
    // 初始化默认白名单数据
    chrome.storage.local.get(['whitelistData'], (result) => {
        if (!result.whitelistData) {
            console.log('初始化默认白名单数据');
            
            const PRESET_PLATFORMS = [
                { name: 'SHEIN', domains: ['shein.com', 'shein.in'], icon: '👗' },
                { name: '亚马逊', domains: ['amazon.com', 'amazon.co.jp', 'amazon.co.uk', 'amazon.de'], icon: '📦' },
                { name: 'eBay', domains: ['ebay.com', 'ebay.co.uk', 'ebay.de'], icon: '🛒' },
                { name: '速卖通', domains: ['aliexpress.com', 'aliexpress.ru'], icon: '🌍' },
                { name: '沃尔玛', domains: ['walmart.com', 'walmart.ca'], icon: '🛍️' }
            ];
            
            let sites = [];
            PRESET_PLATFORMS.forEach(platform => {
                platform.domains.forEach(domain => {
                    sites.push({
                        domain: domain,
                        addedAt: new Date().toISOString(),
                        platform: platform.name,
                        icon: platform.icon
                    });
                });
            });
            
            const whitelistData = {
                sites: sites,
                autoPopup: true,
                lastUpdated: new Date().toISOString()
            };
            
            chrome.storage.local.set({ whitelistData }, () => {
                console.log('默认白名单数据已保存');
                if (chrome.runtime.lastError) {
                    console.error('保存失败:', chrome.runtime.lastError);
                }
            });
        } else {
            console.log('已有白名单数据:', result.whitelistData.sites.length, '个网站');
        }
    });
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        console.log('标签页更新完成:', tab.url);
        
        // 注入内容脚本检查白名单
        setTimeout(() => {
            chrome.tabs.sendMessage(tabId, {
                action: 'checkWhitelist'
            }, (response) => {
                if (chrome.runtime.lastError) {
                    // 内容脚本可能未加载，尝试注入
                    chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        files: ['content.js']
                    }).then(() => {
                        console.log('内容脚本注入成功');
                    }).catch(error => {
                        console.error('注入内容脚本失败:', error);
                    });
                }
            });
        }, 1000);
    }
});

// 接收标签页消息
chrome.runtime.onConnect.addListener((port) => {
    console.log('连接建立:', port.name);
    
    port.onMessage.addListener((msg) => {
        console.log('端口消息:', msg);
    });
    
    port.onDisconnect.addListener(() => {
        console.log('连接断开');
    });
});