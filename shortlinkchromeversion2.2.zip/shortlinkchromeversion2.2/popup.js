// popup.js - 简化版本，只获取链接
console.log('MiniUrl popup 已加载');

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM 已加载');
    
    // 获取所有元素
    const elements = {
        loading: document.getElementById('loadingState'),
        mainContent: document.getElementById('mainContent'),
        currentUrl: document.getElementById('currentUrl'),
        generateBtn: document.getElementById('generateBtn'),
        refreshBtn: document.getElementById('refreshBtn'),
        resultSection: document.getElementById('resultSection'),
        shortLink: document.getElementById('shortLink'),
        copyBtn: document.getElementById('copyBtn'),
        expireInfo: document.getElementById('expireInfo'),
        statusBar: document.getElementById('statusBar'),
        adminLoginBtn: document.getElementById('adminLoginBtn'),
        
        // 白名单相关元素
        whitelistToggleBtn: document.getElementById('whitelistToggleBtn'),
        whitelistSection: document.getElementById('whitelistSection'),
        platformButtons: document.getElementById('platformButtons'),
        whitelistList: document.getElementById('whitelistList'),
        whitelistInput: document.getElementById('whitelistInput'),
        addWhitelistBtn: document.getElementById('addWhitelistBtn'),
        autoPopupToggle: document.getElementById('autoPopupToggle'),
        clearWhitelistBtn: document.getElementById('clearWhitelistBtn'),
        whitelistCount: document.getElementById('whitelistCount'),
        
        // 免责声明相关
        disclaimerToggle: document.getElementById('disclaimerToggle'),
        disclaimerContent: document.getElementById('disclaimerContent'),
        disclaimerToggleIcon: document.getElementById('disclaimerToggleIcon')
    };
    
    // API配置
    const CONFIG = {
        API_ENDPOINT: 'https://shorturlink.qzz.io',
        ADMIN_LOGIN_URL: 'https://shorturlink.qzz.io/admin/login'
    };
    
    // 预设平台
    const PRESET_PLATFORMS = [
        { name: 'SHEIN', domains: ['shein.com', 'shein.in'], icon: '👗' },
        { name: '亚马逊', domains: ['amazon.com', 'amazon.co.jp', 'amazon.co.uk', 'amazon.de'], icon: '📦' },
        { name: 'eBay', domains: ['ebay.com', 'ebay.co.uk', 'ebay.de'], icon: '🛒' },
        { name: '速卖通', domains: ['aliexpress.com', 'aliexpress.ru'], icon: '🌍' },
        { name: '沃尔玛', domains: ['walmart.com', 'walmart.ca'], icon: '🛍️' },
        { name: '乐天', domains: ['rakuten.co.jp', 'rakuten.com'], icon: '🇯🇵' },
        { name: 'Wish', domains: ['wish.com'], icon: '✨' },
        { name: 'Etsy', domains: ['etsy.com'], icon: '🎨' },
        { name: 'Shopee', domains: ['shopee.sg', 'shopee.co.id'], icon: '🦐' },
        { name: 'Lazada', domains: ['lazada.sg', 'lazada.co.id'], icon: '📱' }
    ];
    
    // 白名单数据
    let whitelistData = {
        sites: [],
        autoPopup: true,
        lastUpdated: null
    };
    
    let currentUrl = '';
    
    // 初始化
    async function init() {
        console.log('初始化开始');
        
        // 检查是否是自动模式
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('auto') === 'true') {
            console.log('自动模式激活');
            showStatus('✅ 自动检测模式', 'success');
        }
        
        // 并行加载数据
        try {
            await loadWhitelistData();
            await getCurrentUrl();
            
            bindEvents();
            initUIComponents();
            hideLoading();
            showMainContent();
            updateUI();
            showStatus('系统就绪');
            
        } catch (error) {
            console.error('初始化失败:', error);
            showError('初始化失败');
            setTimeout(() => {
                hideLoading();
                showMainContent();
                showStatus('请刷新重试');
            }, 1000);
        }
    }
    
    // 加载白名单数据
    function loadWhitelistData() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['whitelistData'], (result) => {
                if (result.whitelistData) {
                    whitelistData = result.whitelistData;
                    console.log('白名单加载成功:', whitelistData.sites.length + '个网站');
                } else {
                    // 初始化默认数据
                    whitelistData = {
                        sites: [],
                        autoPopup: true,
                        lastUpdated: new Date().toISOString()
                    };
                    saveWhitelistData();
                }
                
                // 设置自动弹出开关
                if (elements.autoPopupToggle) {
                    elements.autoPopupToggle.checked = whitelistData.autoPopup !== false;
                }
                
                resolve();
            });
        });
    }
    
    // 保存白名单数据
    function saveWhitelistData() {
        whitelistData.lastUpdated = new Date().toISOString();
        
        chrome.storage.local.set({ whitelistData: whitelistData }, () => {
            console.log('白名单已保存');
            updateWhitelistCount();
        });
    }
    
    // 获取当前URL
    function getCurrentUrl() {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                
                if (!tabs || tabs.length === 0) {
                    reject(new Error('未找到标签页'));
                    return;
                }
                
                const tab = tabs[0];
                currentUrl = tab.url || '';
                
                console.log('当前URL:', currentUrl);
                
                // 更新URL显示
                if (elements.currentUrl && currentUrl) {
                    const shortUrl = currentUrl.length > 60 
                        ? currentUrl.substring(0, 60) + '...' 
                        : currentUrl;
                    elements.currentUrl.textContent = shortUrl;
                    elements.currentUrl.title = currentUrl;
                }
                
                resolve();
            });
        });
    }
    
    // 初始化UI组件
    function initUIComponents() {
        renderPresetPlatforms();
        renderWhitelistList();
        updateWhitelistCount();
        initDisclaimer();
    }
    
    // 渲染预设平台
    function renderPresetPlatforms() {
        if (!elements.platformButtons) return;
        
        let html = '';
        PRESET_PLATFORMS.forEach((platform, index) => {
            const isAdded = platform.domains.every(domain => 
                whitelistData.sites.some(site => site.domain === domain)
            );
            
            html += `
                <button class="platform-btn ${isAdded ? 'active' : ''}" 
                        data-index="${index}"
                        title="${platform.domains.join(', ')}">
                    ${isAdded ? '✅' : platform.icon} ${platform.name}
                </button>
            `;
        });
        
        elements.platformButtons.innerHTML = html;
        
        // 绑定平台按钮事件
        elements.platformButtons.querySelectorAll('.platform-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = parseInt(this.dataset.index);
                togglePresetPlatform(index);
            });
        });
    }
    
    // 切换预设平台
    function togglePresetPlatform(index) {
        const platform = PRESET_PLATFORMS[index];
        if (!platform) return;
        
        const allAdded = platform.domains.every(domain => 
            whitelistData.sites.some(site => site.domain === domain)
        );
        
        if (allAdded) {
            // 移除平台所有域名
            platform.domains.forEach(domain => {
                removeWhitelistSite(domain);
            });
            showNotification(`已移除 ${platform.name}`);
        } else {
            // 添加平台所有域名
            let addedCount = 0;
            platform.domains.forEach(domain => {
                if (!whitelistData.sites.some(site => site.domain === domain)) {
                    whitelistData.sites.push({
                        domain: domain,
                        addedAt: new Date().toISOString(),
                        platform: platform.name,
                        icon: platform.icon
                    });
                    addedCount++;
                }
            });
            
            if (addedCount > 0) {
                saveWhitelistData();
                showNotification(`已添加 ${platform.name} (${addedCount}个域名)`);
            }
        }
        
        renderPresetPlatforms();
        renderWhitelistList();
    }
    
    // 渲染白名单列表
    function renderWhitelistList() {
        if (!elements.whitelistList) return;
        
        if (whitelistData.sites.length === 0) {
            elements.whitelistList.innerHTML = `
                <div style="text-align: center; color: #999; padding: 20px;">
                    暂无白名单网站，请添加或选择预设平台
                </div>
            `;
            return;
        }
        
        // 按平台分组
        const groupedSites = {};
        whitelistData.sites.forEach(site => {
            if (!groupedSites[site.platform]) {
                groupedSites[site.platform] = [];
            }
            groupedSites[site.platform].push(site);
        });
        
        let html = '';
        Object.keys(groupedSites).forEach(platform => {
            const sites = groupedSites[platform];
            const platformIcon = PRESET_PLATFORMS.find(p => p.name === platform)?.icon || '🌐';
            
            html += `
                <div style="margin-bottom: 10px;">
                    <div style="font-size: 11px; color: #666; margin-bottom: 5px; padding-left: 5px;">
                        ${platformIcon} ${platform}
                    </div>
            `;
            
            sites.forEach((site, index) => {
                html += `
                    <div class="whitelist-item">
                        <div>
                            <span class="whitelist-domain">${site.domain}</span>
                        </div>
                        <div class="whitelist-actions">
                            <button class="whitelist-action-btn delete" 
                                    data-domain="${site.domain}" 
                                    title="删除">
                                ❌
                            </button>
                        </div>
                    </div>
                `;
            });
            
            html += `</div>`;
        });
        
        elements.whitelistList.innerHTML = html;
        
        // 绑定删除按钮事件
        elements.whitelistList.querySelectorAll('.delete').forEach(btn => {
            btn.addEventListener('click', function() {
                const domain = this.dataset.domain;
                if (domain && confirm(`确定要从白名单中移除 ${domain} 吗？`)) {
                    removeWhitelistSite(domain);
                }
            });
        });
    }
    
    // 移除白名单网站
    function removeWhitelistSite(domain) {
        whitelistData.sites = whitelistData.sites.filter(site => site.domain !== domain);
        saveWhitelistData();
        renderWhitelistList();
        renderPresetPlatforms();
        showNotification(`已移除: ${domain}`);
    }
    
    // 更新白名单计数
    function updateWhitelistCount() {
        if (elements.whitelistCount) {
            const count = whitelistData.sites.length;
            elements.whitelistCount.textContent = `${count}个网站`;
        }
    }
    
    // 初始化免责声明
    function initDisclaimer() {
        if (!elements.disclaimerToggle || !elements.disclaimerContent) return;
        
        // 加载设置
        chrome.storage.local.get(['disclaimerExpanded'], (result) => {
            const isExpanded = result.disclaimerExpanded !== false; // 默认展开
            
            if (isExpanded) {
                elements.disclaimerContent.classList.add('show');
                if (elements.disclaimerToggleIcon) {
                    elements.disclaimerToggleIcon.textContent = '▲';
                }
            }
        });
        
        // 点击切换
        elements.disclaimerToggle.addEventListener('click', () => {
            const isShowing = elements.disclaimerContent.classList.toggle('show');
            
            if (elements.disclaimerToggleIcon) {
                elements.disclaimerToggleIcon.textContent = isShowing ? '▲' : '▼';
            }
            
            // 保存偏好
            chrome.storage.local.set({
                disclaimerExpanded: isShowing
            });
        });
    }
    
    // 绑定事件
function bindEvents() {
    // 管理员按钮 - 改为普通链接点击事件
    if (elements.adminLoginBtn) {
        elements.adminLoginBtn.addEventListener('click', (e) => {
            e.preventDefault(); // 阻止默认链接跳转
            chrome.tabs.create({ url: CONFIG.ADMIN_LOGIN_URL });
        });
    }
        
        // 生成按钮
        if (elements.generateBtn) {
            elements.generateBtn.addEventListener('click', generateShortUrl);
        }
        
        // 刷新按钮
        if (elements.refreshBtn) {
            elements.refreshBtn.addEventListener('click', () => {
                showStatus('刷新中...');
                getCurrentUrl()
                    .then(() => {
                        showStatus('刷新完成');
                        setTimeout(() => showStatus('就绪'), 1000);
                    })
                    .catch(error => {
                        showError('刷新失败');
                    });
            });
        }
        
        // 复制按钮
        if (elements.copyBtn) {
            elements.copyBtn.addEventListener('click', async () => {
                const url = elements.shortLink.href;
                if (!url) {
                    showNotification('没有可复制的内容', 'error');
                    return;
                }
                
                try {
                    await navigator.clipboard.writeText(url);
                    
                    // 按钮反馈
                    const originalText = elements.copyBtn.innerHTML;
                    elements.copyBtn.innerHTML = '<span>✅</span> 已复制';
                    elements.copyBtn.disabled = true;
                    
                    showNotification('短链接已复制到剪贴板');
                    showStatus('✅ 已复制到剪贴板', 'success');
                    
                    // 2秒后恢复按钮
                    setTimeout(() => {
                        elements.copyBtn.innerHTML = originalText;
                        elements.copyBtn.disabled = false;
                    }, 2000);
                    
                } catch (err) {
                    showError('复制失败');
                }
            });
        }
        
        // 点击URL查看完整
        if (elements.currentUrl) {
            elements.currentUrl.addEventListener('click', () => {
                if (currentUrl) {
                    alert('完整URL:\n' + currentUrl);
                }
            });
        }
        
        // 白名单管理按钮
        if (elements.whitelistToggleBtn) {
            elements.whitelistToggleBtn.addEventListener('click', toggleWhitelistSection);
        }
        
        // 添加白名单
        if (elements.addWhitelistBtn) {
            elements.addWhitelistBtn.addEventListener('click', addWhitelist);
        }
        
        // 白名单输入框回车
        if (elements.whitelistInput) {
            elements.whitelistInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') addWhitelist();
            });
        }
        
        // 自动弹出开关
        if (elements.autoPopupToggle) {
            elements.autoPopupToggle.addEventListener('change', function() {
                whitelistData.autoPopup = this.checked;
                saveWhitelistData();
                
                if (this.checked) {
                    showNotification('自动检测功能已开启');
                    showStatus('✅ 自动检测已开启', 'success');
                } else {
                    showNotification('自动检测功能已关闭');
                    showStatus('⏸️ 自动检测已关闭');
                }
            });
        }
        
        // 清空白名单
        if (elements.clearWhitelistBtn) {
            elements.clearWhitelistBtn.addEventListener('click', () => {
                if (whitelistData.sites.length === 0) {
                    showNotification('白名单已经是空的', 'warning');
                    return;
                }
                
                if (confirm(`确定要清空所有 ${whitelistData.sites.length} 个白名单网站吗？`)) {
                    whitelistData.sites = [];
                    saveWhitelistData();
                    renderWhitelistList();
                    renderPresetPlatforms();
                    showNotification('已清空白名单');
                }
            });
        }
    }
    
    // 切换白名单区域显示
    function toggleWhitelistSection() {
        const isShowing = elements.whitelistSection.style.display === 'block';
        elements.whitelistSection.style.display = isShowing ? 'none' : 'block';
        
        if (elements.whitelistToggleBtn) {
            elements.whitelistToggleBtn.innerHTML = isShowing ? 
                '<span>📋</span> 管理网站白名单' : 
                '<span>❌</span> 关闭白名单';
        }
        
        // 滚动到白名单区域
        if (!isShowing) {
            setTimeout(() => {
                elements.whitelistSection.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }, 100);
        }
    }
    
    // 添加白名单
    function addWhitelist() {
        if (!elements.whitelistInput) return;
        
        let domain = elements.whitelistInput.value.trim().toLowerCase();
        
        if (!domain) {
            showNotification('请输入域名', 'error');
            return;
        }
        
        // 清理域名
        domain = domain.replace(/^https?:\/\//, '')
                      .replace(/^www\./, '')
                      .split('/')[0]
                      .split('?')[0];
        
        // 验证域名格式
        if (!/^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$/.test(domain)) {
            showNotification('域名格式不正确（如：amazon.com）', 'error');
            return;
        }
        
        // 检查是否已存在
        if (whitelistData.sites.some(site => site.domain === domain)) {
            showNotification('域名已存在', 'warning');
            return;
        }
        
        // 识别平台
        let platform = '自定义';
        let icon = '🌐';
        
        for (const preset of PRESET_PLATFORMS) {
            if (preset.domains.some(d => domain === d || domain.endsWith('.' + d))) {
                platform = preset.name;
                icon = preset.icon;
                break;
            }
        }
        
        // 添加到白名单
        whitelistData.sites.push({
            domain: domain,
            addedAt: new Date().toISOString(),
            platform: platform,
            icon: icon
        });
        
        saveWhitelistData();
        elements.whitelistInput.value = '';
        renderWhitelistList();
        renderPresetPlatforms();
        
        showNotification(`已添加: ${domain}`);
    }
    
    // 更新UI状态
function updateUI() {
    if (!elements.generateBtn) return;
    
    const blockedDomains = ['temu.com', 'chrome://', 'edge://', 'about:', 'file://', 'data:', 'javascript:'];
    const hasValidUrl = currentUrl && 
                       !blockedDomains.some(domain => currentUrl.includes(domain));
    
    elements.generateBtn.disabled = !hasValidUrl;
    
    if (hasValidUrl) {
        elements.generateBtn.innerHTML = '<span>✨</span> 生成短链接';
        elements.generateBtn.title = '为当前页面生成短链接';
    } else {
        if (currentUrl && currentUrl.includes('temu.com')) {
            elements.generateBtn.innerHTML = '<span>🚫</span> TEMU禁止生成';
            elements.generateBtn.title = 'TEMU平台链接禁止生成短链接';
        } else {
            elements.generateBtn.innerHTML = '<span>⛔</span> 当前页面不支持';
            elements.generateBtn.title = '当前页面不支持生成短链接';
        }
    }
}
    
    // 生成短链接
async function generateShortUrl() {
    if (!currentUrl) {
        showNotification('请先获取页面URL', 'error');
        return;
    }
    
    // 检查URL是否有效
    const blockedDomains = ['temu.com', 'chrome://', 'about:'];
    const isBlocked = blockedDomains.some(domain => currentUrl.includes(domain));
    
    if (isBlocked) {
        if (currentUrl.includes('temu.com')) {
            showNotification('当前页面不支持生成短链接', 'error');
        } else {
            showNotification('当前页面不支持生成短链接', 'error');
        }
        return;
    }
    
    console.log('开始生成短链接:', currentUrl);
    
    // 更新状态
    elements.generateBtn.disabled = true;
    elements.generateBtn.innerHTML = '<span>⏳</span> 生成中...';
    showStatus('正在生成短链接...', 'loading');
        
        try {
            const response = await fetch(CONFIG.API_ENDPOINT + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    longUrl: currentUrl
                })
            });
            
            console.log('API响应状态:', response.status);
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`服务器错误: ${response.status} - ${errorText}`);
            }
            
            const data = await response.json();
            console.log('API响应数据:', data);
            
            let shortUrl;
            if (Array.isArray(data) && data.length > 0 && data[0].short) {
                shortUrl = data[0].short;
            } else if (data.short) {
                shortUrl = data.short;
            } else if (typeof data === 'string' && data.startsWith('http')) {
                shortUrl = data;
            } else {
                throw new Error('无法解析服务器响应');
            }
            
            // 显示结果
            elements.shortLink.href = shortUrl;
            elements.shortLink.textContent = shortUrl;
            elements.resultSection.style.display = 'block';
            
            // 计算过期时间
            const expireTime = new Date(Date.now() + 48 * 60 * 60 * 1000);
            const expireText = expireTime.toLocaleString('zh-CN', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            if (elements.expireInfo) {
                elements.expireInfo.textContent = `有效期至: ${expireText}`;
            }
            
            showStatus('✅ 短链接生成成功！', 'success');
            
        } catch (error) {
            console.error('生成失败:', error);
            showNotification('生成短链接失败: ' + error.message, 'error');
            showStatus('❌ 生成失败', 'error');
        } finally {
            // 恢复按钮状态
            elements.generateBtn.disabled = false;
            updateUI();
        }
    }
    
    // 工具函数
    function showStatus(message, type = '') {
        if (!elements.statusBar) return;
        
        elements.statusBar.textContent = message;
        elements.statusBar.className = 'status-bar';
        
        if (type === 'error') {
            elements.statusBar.style.background = '#ffebee';
            elements.statusBar.style.color = '#c62828';
            elements.statusBar.style.borderColor = '#ffcdd2';
        } else if (type === 'success') {
            elements.statusBar.style.background = '#e8f5e9';
            elements.statusBar.style.color = '#2e7d32';
            elements.statusBar.style.borderColor = '#c8e6c9';
        } else if (type === 'loading') {
            elements.statusBar.style.background = '#fff3e0';
            elements.statusBar.style.color = '#ef6c00';
            elements.statusBar.style.borderColor = '#ffcc80';
        } else {
            elements.statusBar.style.background = '';
            elements.statusBar.style.color = '';
            elements.statusBar.style.borderColor = '';
        }
    }
    
    function showError(message) {
        showStatus('❌ ' + message, 'error');
        setTimeout(() => showStatus('就绪'), 3000);
    }
    
    function showNotification(message, type = 'success') {
        // 简单的alert替代，如果需要更美观可以改为自定义通知
        if (type === 'error') {
            console.error('❌', message);
        } else {
            console.log('✅', message);
        }
    }
    
    function showLoading() {
        if (elements.loading) elements.loading.style.display = 'flex';
        if (elements.mainContent) elements.mainContent.style.display = 'none';
    }
    
    function hideLoading() {
        if (elements.loading) elements.loading.style.display = 'none';
    }
    
    function showMainContent() {
        if (elements.mainContent) elements.mainContent.style.display = 'block';
    }
    
    // 启动
    init();
});