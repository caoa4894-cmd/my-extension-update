// MiniUrl 内容脚本
console.log('MiniUrl 内容脚本加载');

class ContentScript {
    constructor() {
        this.lastUrl = location.href;
        this.init();
    }

    async init() {
        // 检查白名单
        setTimeout(() => this.checkIfWhitelisted(), 1500);
        
        // 监听URL变化（SPA支持）
        this.observeUrlChanges();
        
        // 监听消息
        this.setupMessageListener();
    }

    // 检查是否在白名单中
    async checkIfWhitelisted() {
        const hostname = this.getCleanHostname();
        
        // 检查是否是禁止的域名
        if (hostname.includes('temu.com')) {
            console.log('TEMU平台，跳过自动弹出');
            return;
        }

        try {
            const result = await chrome.storage.local.get(['whitelistData']);
            const whitelistData = result.whitelistData;
            
            if (!whitelistData?.sites || whitelistData.autoPopup === false) {
                return;
            }

            const isWhitelisted = whitelistData.sites.some(site => {
                const domain = site.domain.toLowerCase();
                return hostname === domain || hostname.endsWith('.' + domain);
            });

            if (isWhitelisted) {
                this.sendAutoPopupMessage();
            }
        } catch (error) {
            console.error('检查白名单失败:', error);
        }
    }

    // 发送自动弹出消息
    sendAutoPopupMessage() {
        chrome.runtime.sendMessage({
            action: 'autoPopup',
            url: location.href,
            title: document.title,
            hostname: this.getCleanHostname()
        }).catch(() => {
            // 消息发送失败时静默处理
        });
    }

    // 获取清理后的主机名
    getCleanHostname() {
        return location.hostname.toLowerCase().replace('www.', '');
    }

    // 监听URL变化
    observeUrlChanges() {
        const observer = new MutationObserver(() => {
            const currentUrl = location.href;
            if (currentUrl !== this.lastUrl) {
                this.lastUrl = currentUrl;
                setTimeout(() => this.checkIfWhitelisted(), 500);
            }
        });
        
        observer.observe(document, { 
            subtree: true, 
            childList: true 
        });
    }

    // 设置消息监听器
    setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            switch (message.action) {
                case 'whitelistDetected':
                    console.log('检测到白名单网站:', message.hostname);
                    this.sendAutoPopupMessage();
                    break;
                    
                case 'recheckWhitelist':
                    this.checkIfWhitelisted();
                    break;
            }
            return true;
        });
    }
}

// 启动内容脚本
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new ContentScript();
    });
} else {
    new ContentScript();
}