class MiniUrlPopup {
    constructor() {
        // ========== 新增：动态获取manifest版本 ==========
        const manifest = chrome.runtime.getManifest();
        const manifestVersion = manifest.version || '1.0.0';
        
        this.elements = {
            loading: document.getElementById('loadingState'),
            mainContent: document.getElementById('mainContent'),
            adminLoginBtn: document.getElementById('adminLoginBtn'),
            checkUpdateBtn: document.getElementById('checkUpdateBtn'),
            currentUrl: document.getElementById('currentUrl'),
            generateBtn: document.getElementById('generateBtn'),
            refreshBtn: document.getElementById('refreshBtn'),
            resultSection: document.getElementById('resultSection'),
            shortLink: document.getElementById('shortLink'),
            copyBtn: document.getElementById('copyBtn'),
            expireInfo: document.getElementById('expireInfo'),
            statusBar: document.getElementById('statusBar'),
            disclaimerToggle: document.getElementById('disclaimerToggle'),
            disclaimerContent: document.getElementById('disclaimerContent'),
            whitelistToggleBtn: document.getElementById('whitelistToggleBtn'),
            whitelistSection: document.getElementById('whitelistSection'),
            platformButtons: document.getElementById('platformButtons'),
            whitelistList: document.getElementById('whitelistList'),
            whitelistInput: document.getElementById('whitelistInput'),
            addWhitelistBtn: document.getElementById('addWhitelistBtn'),
            autoPopupToggle: document.getElementById('autoPopupToggle'),
            clearWhitelistBtn: document.getElementById('clearWhitelistBtn'),
            whitelistCount: document.getElementById('whitelistCount'),
            disclaimerToggleIcon: document.getElementById('disclaimerToggleIcon'),
            versionInfo: document.getElementById('versionInfo')
        };

        this.config = {
            API_ENDPOINT: 'https://shorturlink.qzz.io',
            ADMIN_LOGIN_URL: 'https://shorturlink.qzz.io/admin/login',
            GITHUB_RAW_URL: 'https://raw.githubusercontent.com/caoa4894-cmd/my-extension-update/main/update.json',
            CURRENT_VERSION: manifestVersion,  // ← 改为动态获取
            CHECK_INTERVAL: 24 * 60 * 60 * 1000,
            download_url: 'https://github.com/caoa4894-cmd/my-extension-update/releases/download/v{version}/shortlinkchromeversion{version}.zip'
        };

        this.currentTabInfo = {
            url: '',
            title: '',
            id: null,
            domain: '',
            platform: ''
        };

        this.PRESET_PLATFORMS = [
            { name: 'SHEIN', domains: ['shein.com', 'shein.in'], icon: '👗' },
            { name: 'AMAZON', domains: ['amazon.com', 'amazon.co.jp', 'amazon.co.uk', 'amazon.de'], icon: '📦' },
            { name: 'EBay', domains: ['ebay.com', 'ebay.co.uk', 'ebay.de'], icon: '🛒' },
            { name: 'ALIEXPRESS', domains: ['aliexpress.com', 'aliexpress.ru'], icon: '🌍' },
            { name: 'WALMART', domains: ['walmart.com', 'walmart.ca'], icon: '🛍️' },
            { name: 'RAKU', domains: ['rakuten.co.jp', 'rakuten.com'], icon: '🇯🇵' },
            { name: 'WISH', domains: ['wish.com'], icon: '✨' },
            { name: 'ETSY', domains: ['etsy.com'], icon: '🎨' }
        ];

        this.BLOCKED_DOMAINS = ['temu.com'];
        this.whitelistData = { sites: [], autoPopup: true, lastUpdated: null };
        this.updateData = { hasUpdate: false, latestVersion: '', updateContent: '' };

        this.init();
    }

    async init() {
        try {
            this.showLoading();
            await Promise.all([
                this.loadWhitelistData(),
                this.getCurrentTabInfo()
            ]);
            this.bindEvents();
            this.initUIComponents();
            this.hideLoading();
            this.showMainContent();
            this.updateUI();
            this.checkCurrentSite();
            this.updateStatus('系统就绪');
            
            // 延迟检查更新（避免影响主流程）
            setTimeout(() => this.checkForUpdates(false), 2000);
        } catch (error) {
            console.error('初始化失败:', error);
            this.showError('初始化失败');
        }
    }

    async loadWhitelistData() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['whitelistData'], (result) => {
                if (result.whitelistData) {
                    this.whitelistData = result.whitelistData;
                    if (this.elements.autoPopupToggle) {
                        this.elements.autoPopupToggle.checked = this.whitelistData.autoPopup !== false;
                    }
                }
                resolve();
            });
        });
    }

    async getCurrentTabInfo() {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (!tabs?.[0]) {
                    reject(new Error('未找到标签页'));
                    return;
                }

                const tab = tabs[0];
                this.currentTabInfo = {
                    id: tab.id,
                    url: tab.url || '',
                    title: tab.title || ''
                };

                if (this.currentTabInfo.url) {
                    try {
                        const urlObj = new URL(this.currentTabInfo.url);
                        this.currentTabInfo.domain = urlObj.hostname.replace('www.', '');
                        this.currentTabInfo.platform = this.detectPlatformFromUrl(this.currentTabInfo.url);
                    } catch (e) {}
                }

                this.updatePageInfoDisplay();
                resolve();
            });
        });
    }

    detectPlatformFromUrl(url) {
        try {
            const urlObj = new URL(url.toLowerCase());
            const hostname = urlObj.hostname;
            
            for (const platform of this.PRESET_PLATFORMS) {
                for (const domain of platform.domains) {
                    if (hostname.includes(domain) || hostname.endsWith('.' + domain)) {
                        return platform.name;
                    }
                }
            }
            return null;
        } catch {
            return null;
        }
    }

    bindEvents() {
        // 管理员登录
        this.elements.adminLoginBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: this.config.ADMIN_LOGIN_URL });
        });

        // 检查更新
        this.elements.checkUpdateBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            this.checkUpdatesManually();
        });

        // 生成短链接
        this.elements.generateBtn?.addEventListener('click', () => {
            this.generateShortUrl();
        });

        // 刷新链接
        this.elements.refreshBtn?.addEventListener('click', () => {
            this.getCurrentTabInfo();
        });

        // 复制短链接
        this.elements.copyBtn?.addEventListener('click', () => {
            this.copyToClipboard();
        });

        // 查看完整链接
        this.elements.currentUrl?.addEventListener('click', () => {
            if (this.currentTabInfo.url) {
                this.showFullUrl();
            }
        });

        // 白名单管理
        this.elements.whitelistToggleBtn?.addEventListener('click', () => {
            this.toggleWhitelistSection();
        });

        // 添加白名单
        this.elements.addWhitelistBtn?.addEventListener('click', () => {
            this.addWhitelist();
        });

        // 回车添加白名单
        this.elements.whitelistInput?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addWhitelist();
        });

        // 自动检测开关
        this.elements.autoPopupToggle?.addEventListener('change', (e) => {
            this.whitelistData.autoPopup = e.target.checked;
            this.saveWhitelistData();
        });

        // 清空白名单
        this.elements.clearWhitelistBtn?.addEventListener('click', () => {
            this.clearWhitelist();
        });

        // 免责声明
        this.elements.disclaimerToggle?.addEventListener('click', () => {
            this.toggleDisclaimer();
        });
    }

 initUIComponents() {
        this.renderPresetPlatforms();
        this.renderWhitelistList();
        this.updateWhitelistCount();
        this.initDisclaimer();
        
        // 显示版本号 - 修改这里
        if (this.elements.versionInfo) {
            // 使用动态获取的版本号
            this.elements.versionInfo.textContent = `v${this.config.CURRENT_VERSION}`;
            console.log('版本显示已更新:', this.config.CURRENT_VERSION);
        }
    }

    renderPresetPlatforms() {
        if (!this.elements.platformButtons) return;

        this.elements.platformButtons.innerHTML = this.PRESET_PLATFORMS.map((platform, index) => {
            const isAdded = platform.domains.every(domain => 
                this.whitelistData.sites.some(site => site.domain === domain)
            );
            return `
                <button class="platform-btn ${isAdded ? 'active' : ''}" 
                        data-index="${index}">
                    ${isAdded ? '✅' : platform.icon} ${platform.name}
                </button>
            `;
        }).join('');

        this.elements.platformButtons.querySelectorAll('.platform-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.dataset.index);
                this.togglePresetPlatform(index);
            });
        });
    }

    togglePresetPlatform(index) {
        const platform = this.PRESET_PLATFORMS[index];
        if (!platform) return;

        const allAdded = platform.domains.every(domain => 
            this.whitelistData.sites.some(site => site.domain === domain)
        );

        if (allAdded) {
            platform.domains.forEach(domain => {
                this.removeWhitelistSite(domain);
            });
            this.showNotification(`已移除 ${platform.name}`);
        } else {
            let addedCount = 0;
            platform.domains.forEach(domain => {
                if (!this.whitelistData.sites.some(site => site.domain === domain)) {
                    this.whitelistData.sites.push({
                        domain: domain,
                        addedAt: new Date().toISOString(),
                        platform: platform.name,
                        icon: platform.icon
                    });
                    addedCount++;
                }
            });

            if (addedCount > 0) {
                this.saveWhitelistData();
                this.showNotification(`已添加 ${platform.name}`);
            }
        }

        this.renderPresetPlatforms();
        this.renderWhitelistList();
    }

    renderWhitelistList() {
        if (!this.elements.whitelistList) return;

        if (this.whitelistData.sites.length === 0) {
            this.elements.whitelistList.innerHTML = `
                <div style="text-align: center; color: #999; padding: 15px; font-size: 11px;">
                    暂无白名单网站
                </div>
            `;
            return;
        }

        const html = this.whitelistData.sites.map(site => `
            <div class="whitelist-item">
                <div class="whitelist-domain">${site.domain}</div>
                <div class="whitelist-actions">
                    <button class="whitelist-action-btn delete" 
                            data-domain="${site.domain}">
                        ❌
                    </button>
                </div>
            </div>
        `).join('');

        this.elements.whitelistList.innerHTML = html;

        this.elements.whitelistList.querySelectorAll('.delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const domain = e.target.dataset.domain;
                if (domain && confirm(`移除 ${domain}？`)) {
                    this.removeWhitelistSite(domain);
                }
            });
        });
    }

    // 更新检查功能
    async checkForUpdates(manual = false) {
        try {
            // 如果不是手动检查，检查是否需要检查更新
            if (!manual) {
                const lastCheck = localStorage.getItem('lastUpdateCheck');
                const now = Date.now();
                
                // 如果24小时内检查过，跳过
                if (lastCheck && (now - parseInt(lastCheck)) < this.config.CHECK_INTERVAL) {
                    return;
                }
                
                // 检查是否设置了忽略更新
                const hideUntil = localStorage.getItem('hideUpdateUntil');
                if (hideUntil && Date.now() < parseInt(hideUntil)) {
                    return;
                }
            }

            if (manual) {
                this.updateStatus('正在检查更新...', 'loading');
            }
            
            // 从GitHub获取更新信息
            const response = await fetch(`${this.config.GITHUB_RAW_URL}?t=${Date.now()}`, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const updateInfo = await response.json();
            
            // 保存最后检查时间
            localStorage.setItem('lastUpdateCheck', Date.now().toString());
            
            // 比较版本 - 修改这里
            const latestVersion = updateInfo.version || updateInfo.latestVersion || this.config.CURRENT_VERSION;  // ← 用动态版本
            
            if (this.compareVersions(latestVersion, this.config.CURRENT_VERSION) > 0) {
                // 有新版本
                this.updateData = {
                    hasUpdate: true,
                    latestVersion: latestVersion,
                    updateContent: updateInfo.updateContent || updateInfo.changelog || '发现新版本，优化了使用体验！',
                    downloadUrl: updateInfo.downloadUrl || 
                               this.config.download_url.replace(/\{version\}/g, latestVersion)
                };
                
                // 更新检查按钮样式
                this.updateCheckButtonStyle(true);
                
                // 显示更新通知
                this.showUpdateNotification();
                
                if (manual) {
                    this.updateStatus(`发现新版本 v${latestVersion}`, 'success');
                }
            } else {
                // 已是最新版本
                this.updateData.hasUpdate = false;
                this.updateCheckButtonStyle(false);
                
                if (manual) {
                    this.updateStatus('当前已是最新版本', 'success');
                }
            }
            
        } catch (error) {
            console.error('更新检查失败:', error);
            this.updateCheckButtonStyle(false);
            
            if (manual) {
                this.updateStatus('检查更新失败，请检查网络连接', 'error');
            }
        }
    }

    compareVersions(v1, v2) {
        // 移除版本号前的v字符
        v1 = v1.replace(/^v/, '');
        v2 = v2.replace(/^v/, '');
        
        const v1Parts = v1.split('.').map(Number);
        const v2Parts = v2.split('.').map(Number);
        
        for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
            const part1 = v1Parts[i] || 0;
            const part2 = v2Parts[i] || 0;
            if (part1 > part2) return 1;
            if (part1 < part2) return -1;
        }
        return 0;
    }

    updateCheckButtonStyle(hasUpdate) {
        const updateBtn = this.elements.checkUpdateBtn;
        if (!updateBtn) return;
        
        if (hasUpdate) {
            updateBtn.classList.add('new-version');
            updateBtn.innerHTML = '<span>🆕</span> 有更新';
        } else {
            updateBtn.classList.remove('new-version');
            updateBtn.innerHTML = '<span>🔄</span> 检查更新';
        }
    }

    showUpdateNotification() {
        if (!this.updateData.hasUpdate) return;
        
        // 避免重复通知
        const lastNotifiedVersion = localStorage.getItem('lastNotifiedVersion');
        if (lastNotifiedVersion === this.updateData.latestVersion) {
            return;
        }
        
        localStorage.setItem('lastNotifiedVersion', this.updateData.latestVersion);
        
        // 移除已有的通知
        const existingNotification = document.getElementById('updateNotification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // 创建通知弹窗
        const notification = document.createElement('div');
        notification.id = 'updateNotification';
        notification.innerHTML = `
            <div style="margin-bottom: 10px; font-weight: bold; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 18px;">🔄</span>
                <span>发现新版本 v${this.updateData.latestVersion}</span>
            </div>
            <div style="font-size: 12px; margin-bottom: 12px; opacity: 0.9; max-height: 40px; overflow: hidden;">
                ${this.updateData.updateContent || '优化了使用体验，修复了已知问题'}
            </div>
            <div style="display: flex; gap: 8px; justify-content: flex-end;">
                <button id="laterBtn" style="padding: 6px 12px; background: rgba(255,255,255,0.2); 
                        color: white; border: 1px solid rgba(255,255,255,0.3); border-radius: 4px; 
                        cursor: pointer; font-size: 12px;">稍后</button>
                <button id="downloadNowBtn" style="padding: 6px 12px; background: white; 
                        color: #ff9800; border: none; border-radius: 4px; cursor: pointer; 
                        font-weight: bold; font-size: 12px;">立即下载</button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // 添加事件监听
        document.getElementById('laterBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            notification.remove();
            // 24小时内不再提示
            localStorage.setItem('hideUpdateUntil', (Date.now() + 24 * 60 * 60 * 1000).toString());
        });
        
        document.getElementById('downloadNowBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            if (this.updateData.downloadUrl) {
                chrome.tabs.create({ url: this.updateData.downloadUrl });
            }
            notification.remove();
        });
        
        notification.addEventListener('click', (e) => {
            if (e.target === notification || e.target.closest('#updateNotification')) {
                if (this.updateData.downloadUrl) {
                    chrome.tabs.create({ url: this.updateData.downloadUrl });
                }
                notification.remove();
            }
        });
        
        // 10秒后自动消失
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);
    }

    checkUpdatesManually() {
        // 清除缓存，强制检查
        localStorage.removeItem('lastUpdateCheck');
        localStorage.removeItem('hideUpdateUntil');
        localStorage.removeItem('lastNotifiedVersion');
        
        this.checkForUpdates(true);
    }

    async generateShortUrl() {
        if (!this.currentTabInfo.url || this.currentTabInfo.url.includes('temu.com')) {
            this.showNotification('此链接不支持生成短链接', 'error');
            return;
        }

        this.updateStatus('生成中...', 'loading');
        this.setButtonLoading(true);

        try {
            const response = await fetch(`${this.config.API_ENDPOINT}/create`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ longUrl: this.currentTabInfo.url })
            });

            if (!response.ok) throw new Error('生成失败');

            const data = await response.json();
            const shortUrl = Array.isArray(data) && data[0]?.short ? data[0].short : data.short;
            
            if (shortUrl) {
                this.showResult(shortUrl);
                this.updateStatus('生成成功', 'success');
            } else {
                throw new Error('解析响应失败');
            }
        } catch (error) {
            console.error('生成失败:', error);
            this.showError('生成失败');
        } finally {
            this.setButtonLoading(false);
        }
    }

    showResult(shortUrl) {
        if (!this.elements.resultSection || !this.elements.shortLink) return;

        this.elements.shortLink.href = shortUrl;
        this.elements.shortLink.textContent = shortUrl;
        
        const expireTime = new Date(Date.now() + 48 * 60 * 60 * 1000);
        this.elements.expireInfo.textContent = `有效期至: ${expireTime.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}`;
        
        this.elements.resultSection.style.display = 'block';
        setTimeout(() => this.elements.resultSection.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
    }

    async copyToClipboard() {
        const url = this.elements.shortLink.href;
        if (!url) return;

        try {
            await navigator.clipboard.writeText(url);
            const originalText = this.elements.copyBtn.innerHTML;
            this.elements.copyBtn.innerHTML = '<span>✅</span> 已复制';
            this.elements.copyBtn.disabled = true;
            
            this.showNotification('已复制到剪贴板', 'success');
            
            setTimeout(() => {
                if (this.elements.copyBtn) {
                    this.elements.copyBtn.innerHTML = originalText;
                    this.elements.copyBtn.disabled = false;
                }
            }, 2000);
        } catch (err) {
            this.showNotification('复制失败，请手动复制', 'error');
        }
    }

    // 辅助方法
    updatePageInfoDisplay() {
        if (this.elements.currentUrl && this.currentTabInfo.url) {
            const displayUrl = this.currentTabInfo.url.length > 60 
                ? this.currentTabInfo.url.substring(0, 60) + '...' 
                : this.currentTabInfo.url;
            this.elements.currentUrl.textContent = displayUrl;
            this.elements.currentUrl.title = this.currentTabInfo.url;
        }
    }

    saveWhitelistData() {
        this.whitelistData.lastUpdated = new Date().toISOString();
        chrome.storage.local.set({ whitelistData: this.whitelistData }, () => {
            this.updateWhitelistCount();
            chrome.runtime.sendMessage({ action: 'whitelistUpdated' });
        });
    }

    addWhitelist() {
        let domain = this.elements.whitelistInput.value.trim().toLowerCase();
        if (!domain) return;

        if (this.BLOCKED_DOMAINS.some(blocked => domain.includes(blocked))) {
            this.showNotification('此域名禁止添加', 'error');
            return;
        }

        domain = domain.replace(/^https?:\/\//, '')
                      .replace(/^www\./, '')
                      .split('/')[0];

        if (this.whitelistData.sites.some(site => site.domain === domain)) {
            this.showNotification('域名已存在', 'warning');
            return;
        }

        let platform = '自定义';
        let icon = '🌐';

        for (const preset of this.PRESET_PLATFORMS) {
            if (preset.domains.some(d => domain === d || domain.endsWith('.' + d))) {
                platform = preset.name;
                icon = preset.icon;
                break;
            }
        }

        this.whitelistData.sites.push({
            domain: domain,
            addedAt: new Date().toISOString(),
            platform: platform,
            icon: icon
        });

        this.saveWhitelistData();
        this.elements.whitelistInput.value = '';
        this.renderWhitelistList();
        this.renderPresetPlatforms();
        this.showNotification(`已添加: ${domain}`);
    }

    removeWhitelistSite(domain) {
        this.whitelistData.sites = this.whitelistData.sites.filter(site => site.domain !== domain);
        this.saveWhitelistData();
        this.renderWhitelistList();
        this.renderPresetPlatforms();
        this.showNotification(`已移除: ${domain}`);
    }

    clearWhitelist() {
        if (this.whitelistData.sites.length === 0) return;
        if (confirm(`清空 ${this.whitelistData.sites.length} 个网站？`)) {
            this.whitelistData.sites = [];
            this.saveWhitelistData();
            this.renderWhitelistList();
            this.renderPresetPlatforms();
            this.showNotification('已清空白名单', 'success');
        }
    }

    toggleWhitelistSection() {
        const isShowing = this.elements.whitelistSection.style.display === 'block';
        this.elements.whitelistSection.style.display = isShowing ? 'none' : 'block';
        this.elements.whitelistToggleBtn.innerHTML = isShowing 
            ? '<span>📋</span> 管理网站白名单' 
            : '<span>❌</span> 关闭白名单';
    }

    toggleDisclaimer() {
    if (!this.elements.disclaimerContent || !this.elements.disclaimerToggleIcon) return;
    
    const isShowing = this.elements.disclaimerContent.classList.contains('show');
    
    // 切换显示状态
    if (isShowing) {
        // 从展开 -> 折叠：用户主动缩小了
        this.elements.disclaimerContent.classList.remove('show');
        this.elements.disclaimerToggleIcon.textContent = '▼';
    } else {
        // 从折叠 -> 展开
        this.elements.disclaimerContent.classList.add('show');
        this.elements.disclaimerToggleIcon.textContent = '▲';
    }
    
    // 关键：保存用户的选择到存储
    // true 表示用户手动折叠了，下次默认折叠
    // false 或 undefined 表示展开状态（第一次使用）
    chrome.storage.local.set({
        disclaimerCollapsed: !this.elements.disclaimerContent.classList.contains('show')
    });
}

   initDisclaimer() {
    chrome.storage.local.get(['disclaimerCollapsed'], (result) => {
        // 第一次使用时，disclaimerCollapsed 不存在，默认展开
        // 用户手动折叠后，disclaimerCollapsed = true
        const isCollapsed = result.disclaimerCollapsed === true;
        
        if (!this.elements.disclaimerContent || !this.elements.disclaimerToggleIcon) return;
        
        if (!isCollapsed) {
            // 第一次使用或用户手动展开：显示完整内容
            this.elements.disclaimerContent.classList.add('show');
            this.elements.disclaimerToggleIcon.textContent = '▲';
        } else {
            // 用户手动折叠过：不显示内容
            this.elements.disclaimerContent.classList.remove('show');
            this.elements.disclaimerToggleIcon.textContent = '▼';
        }
    });
}

    updateWhitelistCount() {
        if (this.elements.whitelistCount) {
            this.elements.whitelistCount.textContent = `${this.whitelistData.sites.length}个`;
        }
    }

    checkCurrentSite() {
        if (!this.currentTabInfo.domain) return false;
        const isInWhitelist = this.whitelistData.sites.some(site => {
            return this.currentTabInfo.domain === site.domain || 
                   this.currentTabInfo.domain.endsWith('.' + site.domain);
        });
        
        if (isInWhitelist) {
            const platform = this.currentTabInfo.platform || '跨境';
            this.updateStatus(`✅ ${platform} 在白名单中`, 'success');
            return true;
        }
        return false;
    }

    updateUI() {
        if (!this.elements.generateBtn) return;
        
        const invalidProtocols = ['chrome://', 'edge://', 'about:', 'file://', 'data:', 'javascript:'];
        const isBlocked = this.BLOCKED_DOMAINS.some(domain => this.currentTabInfo.url.includes(domain));
        const hasValidUrl = this.currentTabInfo.url && 
                           !invalidProtocols.some(protocol => this.currentTabInfo.url.startsWith(protocol)) &&
                           !isBlocked;
        
        this.elements.generateBtn.disabled = !hasValidUrl;
        
        if (!hasValidUrl && isBlocked) {
            this.elements.generateBtn.innerHTML = '<span>🚫</span> TEMU禁止生成';
        } else if (!hasValidUrl) {
            this.elements.generateBtn.innerHTML = '<span>⛔</span> 不支持';
        } else {
            this.elements.generateBtn.innerHTML = '<span>✨</span> 生成短链接';
        }
    }

    setButtonLoading(isLoading) {
        if (!this.elements.generateBtn) return;
        if (isLoading) {
            this.elements.generateBtn.disabled = true;
            this.elements.generateBtn.innerHTML = '<span>⏳</span> 生成中...';
        } else {
            this.updateUI();
        }
    }

    showFullUrl() {
        if (!this.currentTabInfo.url) return;
        
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); display: flex; align-items: center;
            justify-content: center; z-index: 10000; padding: 20px;
        `;
        
        modal.innerHTML = `
            <div style="background: white; padding: 20px; border-radius: 12px; max-width: 500px; width: 90%;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                    <h3 style="margin: 0; color: #3f51b5;">完整链接</h3>
                    <button style="background: #f44336; color: white; border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer;">×</button>
                </div>
                <div style="background: #f5f7ff; padding: 15px; border-radius: 8px; max-height: 200px; overflow-y: auto;">
                    <pre style="margin: 0; white-space: pre-wrap; color: #303f9f; font-size: 12px;">${this.currentTabInfo.url}</pre>
                </div>
                <div style="margin-top: 15px; display: flex; justify-content: flex-end;">
                    <button id="modalCopyBtn" style="padding: 8px 16px; background: #4caf50; color: white; border: none; border-radius: 6px; cursor: pointer; margin-right: 10px;">复制</button>
                    <button id="modalCloseBtn" style="padding: 8px 16px; background: #3f51b5; color: white; border: none; border-radius: 6px; cursor: pointer;">关闭</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.querySelector('button').addEventListener('click', () => modal.remove());
        modal.querySelector('#modalCloseBtn').addEventListener('click', () => modal.remove());
        modal.querySelector('#modalCopyBtn').addEventListener('click', () => {
            navigator.clipboard.writeText(this.currentTabInfo.url).then(() => {
                this.showNotification('已复制', 'success');
                modal.remove();
            });
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }

    updateStatus(message, type = '') {
        if (!this.elements.statusBar) return;
        this.elements.statusBar.textContent = message;
        this.elements.statusBar.className = 'status-bar';
        if (type) this.elements.statusBar.classList.add(type);
    }

    showError(message) {
        this.updateStatus('❌ ' + message, 'error');
        setTimeout(() => this.updateStatus('就绪'), 3000);
    }

    showNotification(message, type = 'success') {
        console.log(type === 'error' ? '❌' : type === 'warning' ? '⚠️' : '✅', message);
    }

    showLoading() {
        if (this.elements.loading) this.elements.loading.style.display = 'flex';
        if (this.elements.mainContent) this.elements.mainContent.style.display = 'none';
    }

    hideLoading() {
        if (this.elements.loading) this.elements.loading.style.display = 'none';
    }

    showMainContent() {
        if (this.elements.mainContent) this.elements.mainContent.style.display = 'block';
    }
}

// 启动应用
document.addEventListener('DOMContentLoaded', () => {
    new MiniUrlPopup();
});