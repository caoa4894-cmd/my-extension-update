// MiniUrl 后台服务
console.log('MiniUrl 后台服务启动');

// 配置
const CONFIG = {
    PRESET_PLATFORMS: [
        { name: 'SHEIN', domains: ['shein.com', 'shein.in'], icon: '👗' },
            { name: 'AMAZON', domains: ['amazon.com', 'amazon.co.jp', 'amazon.co.uk', 'amazon.de'], icon: '📦' },
            { name: 'EBay', domains: ['ebay.com', 'ebay.co.uk', 'ebay.de'], icon: '🛒' },
            { name: 'ALIEXPRESS', domains: ['aliexpress.com', 'aliexpress.ru'], icon: '🌍' },
            { name: 'WALMART', domains: ['walmart.com', 'walmart.ca'], icon: '🛍️' },
    ]
};

// 消息处理
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('收到消息:', message.action);
    
    switch (message.action) {
        case 'autoPopup':
            handleAutoPopup(message, sendResponse);
            return true;
            
        case 'whitelistUpdated':
            handleWhitelistUpdated();
            sendResponse({ success: true });
            return true;
            
        case 'checkUpdate':
            handleCheckUpdate(sendResponse);
            return true;
    }
});

// 处理自动弹出
async function handleAutoPopup(message, sendResponse) {
    if (message.url?.includes('temu.com')) {
        sendResponse({ success: false, reason: 'temu_blocked' });
        return;
    }

    try {
        const result = await chrome.storage.local.get(['whitelistData']);
        const whitelistData = result.whitelistData;
        
        if (!whitelistData || whitelistData.autoPopup === false) {
            sendResponse({ success: false, reason: 'auto_popup_disabled' });
            return;
        }

        try {
            await chrome.action.openPopup();
            sendResponse({ success: true });
        } catch {
            createNotification(message);
            sendResponse({ success: true, method: 'notification' });
        }
    } catch (error) {
        console.error('自动弹出处理失败:', error);
        sendResponse({ success: false, reason: 'error' });
    }
}

// 创建通知
function createNotification(message) {
    let domain = '跨境平台';
    try {
        if (message.url) {
            const urlObj = new URL(message.url);
            domain = urlObj.hostname.replace('www.', '');
        }
    } catch {}

    const notificationId = 'miniurl-' + Date.now();
    
    chrome.notifications.create(notificationId, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icon.png'),
        title: 'MiniUrl - 检测到跨境平台',
        message: `检测到 ${domain}，点击生成短链接`,
        priority: 1,
        buttons: [{ title: '打开工具' }],
        silent: true
    });

    // 5秒后自动清除
    setTimeout(() => {
        chrome.notifications.clear(notificationId);
    }, 5000);
}

// 通知点击处理
chrome.notifications.onClicked.addListener((notificationId) => {
    if (notificationId.startsWith('miniurl-')) {
        chrome.action.openPopup().catch(console.error);
        chrome.notifications.clear(notificationId);
    }
});

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (notificationId.startsWith('miniurl-') && buttonIndex === 0) {
        chrome.action.openPopup().catch(console.error);
        chrome.notifications.clear(notificationId);
    }
});

// 白名单更新处理
function handleWhitelistUpdated() {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            if (tab.url?.startsWith('http')) {
                chrome.tabs.sendMessage(tab.id, { 
                    action: 'recheckWhitelist' 
                }).catch(() => {});
            }
        });
    });
}

// 更新检查处理
function handleCheckUpdate(sendResponse) {
    sendResponse({ 
        success: true, 
        message: '更新检查由前台处理',
        timestamp: Date.now()
    });
}

// 扩展安装/更新
chrome.runtime.onInstalled.addListener(handleExtensionInstalled);

async function handleExtensionInstalled(details) {
    console.log(`扩展${details.reason}:`, chrome.runtime.getManifest().version);
    
    await Promise.all([
        initializeWhitelistData(),
        initializeSettings()
    ]);

    if (details.reason === 'update') {
        showUpdateNotification(details.previousVersion);
    }
}

// 初始化白名单数据
async function initializeWhitelistData() {
    const result = await chrome.storage.local.get(['whitelistData']);
    
    if (!result.whitelistData) {
        console.log('初始化默认白名单');
        
        const sites = CONFIG.PRESET_PLATFORMS.flatMap(platform => 
            platform.domains.map(domain => ({
                domain: domain,
                addedAt: new Date().toISOString(),
                platform: platform.name,
                icon: platform.icon
            }))
        );

        const whitelistData = {
            sites,
            autoPopup: true,
            lastUpdated: new Date().toISOString(),
            version: chrome.runtime.getManifest().version
        };

        await chrome.storage.local.set({ whitelistData });
    }
}

// 初始化设置
async function initializeSettings() {
    const result = await chrome.storage.local.get(['settings']);
    
    const defaultSettings = {
        autoPopup: true,
        showNotifications: true,
        installedVersion: chrome.runtime.getManifest().version,
        installationDate: new Date().toISOString()
    };

    const settings = result.settings || defaultSettings;
    settings.installedVersion = chrome.runtime.getManifest().version;
    
    await chrome.storage.local.set({ settings });
}

// 显示更新通知
function showUpdateNotification(previousVersion) {
    const currentVersion = chrome.runtime.getManifest().version;
    
    chrome.notifications.create(`update-${currentVersion}`, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icon.png'),
        title: `MiniUrl 已更新到 v${currentVersion}`,
        message: '点击查看新功能',
        priority: 1,
        silent: true
    });
}

// 标签页更新监听
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url?.startsWith('http')) {
        setTimeout(() => checkAndNotifyWhitelist(tabId, tab.url), 1000);
    }
});

// 检查白名单并通知
async function checkAndNotifyWhitelist(tabId, url) {
    try {
        const result = await chrome.storage.local.get(['whitelistData', 'settings']);
        const { whitelistData, settings } = result;
        
        if (!settings?.autoPopup) return;
        if (!whitelistData?.sites?.length) return;

        const urlObj = new URL(url);
        const hostname = urlObj.hostname.toLowerCase().replace('www.', '');
        
        const isWhitelisted = whitelistData.sites.some(site => {
            const domain = site.domain.toLowerCase();
            return hostname === domain || hostname.endsWith('.' + domain);
        });

        if (isWhitelisted) {
            chrome.tabs.sendMessage(tabId, {
                action: 'whitelistDetected',
                url: url,
                hostname: hostname
            }).catch(async () => {
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        files: ['content.js']
                    });
                    setTimeout(() => {
                        chrome.tabs.sendMessage(tabId, {
                            action: 'whitelistDetected',
                            url: url,
                            hostname: hostname
                        }).catch(() => {});
                    }, 500);
                } catch (error) {
                    console.error('注入脚本失败:', error);
                }
            });
        }
    } catch (error) {
        console.error('检查白名单失败:', error);
    }
}

// 标签页激活监听
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab?.url?.startsWith('http')) {
            console.log('激活标签页:', tab.url);
        }
    });
});

// 保持service worker活跃
let heartbeatInterval = setInterval(() => {
    console.log('Service worker活跃');
}, 4 * 60 * 1000);

chrome.runtime.onSuspend.addListener(() => {
    clearInterval(heartbeatInterval);
});

console.log('MiniUrl 后台服务初始化完成');